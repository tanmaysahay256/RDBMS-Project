don_list = [['Fortis', '04/10/2023', '09:03:00']]
print(don_list)
for i in don_list:
    for j in i:
        print(j)